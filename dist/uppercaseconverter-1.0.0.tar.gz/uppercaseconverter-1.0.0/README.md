# UppercaseConverter

UppercaseConverter is a simple Python package to convert the content of a file to uppercase.

## Installation

```sh
pip install UppercaseConverter
